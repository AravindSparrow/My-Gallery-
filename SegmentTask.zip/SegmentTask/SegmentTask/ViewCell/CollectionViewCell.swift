//
//  CollectionViewCell.swift
//  SegmentTask
//
//  Created by Aravind raj on 15/01/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    //MARK: collection view cell 
    @IBOutlet weak var CollectionViewImage: UIImageView!
    @IBOutlet weak var CollectionViewLable: UILabel!
    
}
