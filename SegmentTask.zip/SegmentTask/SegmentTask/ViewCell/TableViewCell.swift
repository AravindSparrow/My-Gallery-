//
//  TableViewCell.swift
//  SegmentTask
//
//  Created by Aravind raj on 15/01/21.
//

import UIKit

class TableViewCell: UITableViewCell {

    // MARK: Tableview cell outlet
    @IBOutlet weak var tableLable: UILabel!
    @IBOutlet weak var TableImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state

        // MARK: Frame Design
        TableImage.layer.cornerRadius = 42.0
        TableImage.layer.borderWidth = 2.0

    }

}
