//
//  DetailsViewController.swift
//  SegmentTask
//
//  Created by Aravind raj on 15/01/21.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var passedValue = String()
    var getimage = UIImage()

    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var lableView: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        lableView.text = passedValue
        ImageView.image = getimage
        
        
    }
    
    
    
    
}
