//
//  ViewController.swift
//  SegmentTask
//
//  Created by Aravind raj on 15/01/21.
//

import UIKit

class ViewController: UIViewController {

    //MARK: My Array
    let CricketerDhoni = ["Image  One","Image  Two","Image  Three","Image  Four","Image  Five", "Image  Six"]
    let CricketerDhonImagei = [UIImage(named: "imageone"), UIImage(named: "imagetwo"), UIImage(named: "imagethree"), UIImage(named: "imagefour"), UIImage(named: "imagefive"), UIImage(named: "imagesix")]

    //MARK: UI outlet
    @IBOutlet weak var viewInCollectionView: UIView!
    @IBOutlet weak var viewInTableview: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    var index:Int = 0

    //MARK: SegmentedControl outlet
    @IBOutlet weak var segmentScreen: UISegmentedControl!
    @IBAction func SegMentAction(_ sender: Any) {

        switch segmentScreen.selectedSegmentIndex {
        case 0: viewInTableview.isHidden = false; viewInCollectionView.isHidden = true
        case 1: viewInTableview.isHidden = true; viewInCollectionView.isHidden = false
        default: break
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        //MARK: SegmentedControl Code
        viewInTableview.isHidden = false
        viewInCollectionView.isHidden = true
        segmentScreen.setTitle("list", forSegmentAt: 0)
        segmentScreen.setTitle("Grid", forSegmentAt: 1)
        segmentScreen.selectedSegmentIndex = 0
    }
}

//MARK: TableViewDataSource
extension ViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CricketerDhoni.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let tableviewcell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        tableviewcell.tableLable.text = CricketerDhoni[indexPath.row]
        tableviewcell.TableImage.image = CricketerDhonImagei[indexPath.row]

        return tableviewcell
    }
}

//MARK: TableViewDelegate
extension ViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(CricketerDhoni[indexPath.row])
        index  = indexPath.row
        alert()
    }

}


//MARK: CollectionViewDataSource
extension ViewController: UICollectionViewDataSource  {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return CricketerDhoni.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let collectionviewcell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell

        collectionviewcell.CollectionViewImage.image = CricketerDhonImagei[indexPath.row]
        collectionviewcell.CollectionViewLable.text = CricketerDhoni[indexPath.row]
        collectionviewcell.CollectionViewImage.layer.cornerRadius = 82.0
        collectionviewcell.CollectionViewImage.layer.borderWidth = 2.0

        return collectionviewcell
    }

}

//MARK: CollectionViewDelegateFlowLayout
extension ViewController: UICollectionViewDelegateFlowLayout  {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        let width = (CGFloat(UIScreen.main.bounds.size.width) - CGFloat(10 + 10 + 10))/2
        let height = CGFloat(215)
        return CGSize(width: width, height: height)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
    }
}

//MARK: CollectionViewDelegate
extension ViewController: UICollectionViewDelegate  {

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        index  = indexPath.item
        alert()

    }

}

//MARK: Alert Function
extension ViewController  {

    func alert() {

        let alert = UIAlertController(title: "Dhoni", message: "Detail !", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Get Info", style: UIAlertAction.Style.default, handler: { (alertAction) -> Void in
            self.performSegue(withIdentifier: "gotoNext", sender: self)
        }))
        self.present(alert, animated: true, completion: nil)
    }

}

//MARK: Data passing to DetailView Controller
extension ViewController {

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "gotoNext" {
            if segue.destination.isKind(of: DetailsViewController.self) {
                let secondVC = segue.destination as! DetailsViewController
                secondVC.passedValue = CricketerDhoni[index]
                secondVC.getimage = CricketerDhonImagei[index]!
            }
        }
    }
}
